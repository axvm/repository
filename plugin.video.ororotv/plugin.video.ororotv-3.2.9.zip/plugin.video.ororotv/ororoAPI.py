# -*- coding: utf-8 -*-

'''
    Copyright (C) 2015 ororo.tv

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2, urllib, base64, os, xbmcaddon, xbmc
try:    import json
except: import simplejson as json

# TODO: maybe it must be singleton?

class OroroAPI:
    def __init__(self, login=None, password=None):
        self.protocol = 'https://'
        self.url = "ororo.tv"
        self.api_prefix = "/api/v1"

        if login and password:
            self.set_credentials(login, password)

    def addon_version(self): #TODO: move me to plugin top level
        return xbmcaddon.Addon().getAddonInfo("version")

    def api_url(self):
        return self.url + self.api_prefix

    def base_url_with_credentials(self):
        return self.protocol + '%s:%s@' % (urllib.quote_plus(self.login), urllib.quote_plus(self.password)) + self.url

    def api_with_credentials_url(self):
        return self.protocol + '%s:%s@' % (urllib.quote_plus(self.login), urllib.quote_plus(self.password)) + self.api_url()

    def is_have_credentials(self):
        return self.login and self.password

    def new_request(self, uri, method, data=None):
        request = urllib2.Request(self.protocol + self.url + self.api_prefix + uri, data)
        request.add_header('Accept', 'application/json')
        request.add_header('Content-Type', 'application/json')
        request.add_header('User-Agent', 'Kodi (%s)' % self.addon_version())

        if self.is_have_credentials():
            request.add_header("Authorization", "Basic %s" % self.generate_auth_header())

        return request

    def set_credentials(self, login, password):
        self.login = login
        self.password = password

    def generate_auth_header(self):
        return base64.b64encode('%s:%s' % (self.login, self.password))

    def make_request(self, uri, method='GET', params=None):
        return urllib2.urlopen(self.new_request(uri, method, params))

    def get(self, uri, params=None):
        try:
            res = self.make_request(uri, params)
            return res.read()
        except urllib2.HTTPError as e:
            if e.getcode() == 401:
              code = 30516 # Failed to log in
            else:
              code = 30320 # General "Load failed" error

            str = xbmcaddon.Addon().getLocalizedString(code).encode('utf-8')
            addonIcon = os.path.join(xbmcaddon.Addon().getAddonInfo("path"),'icon.png')
            try: xbmcgui.Dialog().notification('Ororo TV', str, addonIcon, 3000, sound=False)
            except: xbmc.executebuiltin("Notification(%s,%s, 3000, %s)" % ('Ororo TV', str, addonIcon))

    def shows_list(self):
        return self.get('/shows')

    def movies_list(self):
        return self.get('/movies')

    def show(self, show_id):
        return self.get('/shows/' + str(show_id))

    def video(self, video_id):
        return self.get('/videos/' + str(video_id))

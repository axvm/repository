# -*- coding: utf-8 -*-

'''
    Copyright (C) 2015 ororo.tv

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs,urllib,urllib2,sys,os,base64
addonId = xbmcaddon.Addon().getAddonInfo("id")

class contextMenu:
    def __init__(self, indexClass):
        self.index = indexClass

    def item_play(self):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        xbmc.executebuiltin('Action(Queue)')
        playlist.unshuffle()
        xbmc.Player().play(playlist)

    def item_random_play(self):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        xbmc.executebuiltin('Action(Queue)')
        playlist.shuffle()
        xbmc.Player().play(playlist)

    def item_queue(self):
        xbmc.executebuiltin('Action(Queue)')

    def item_play_from_here(self, url):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.unshuffle()
        total = xbmc.getInfoLabel('Container.NumItems')
        for i in range(0, int(total)):
            i = str(i)
            label = xbmc.getInfoLabel('ListItemNoWrap(%s).Label' % i)
            if label == '': break

            params = {}
            path = xbmc.getInfoLabel('ListItemNoWrap(%s).FileNameAndPath' % i)
            path = urllib.quote_plus(path).replace('+%26+', '+&+')
            query = path.split('%3F', 1)[-1].split('%26')
            for i in query: params[urllib.unquote_plus(i).split('=')[0]] = urllib.unquote_plus(i).split('=')[1]
            sysname = urllib.quote_plus(params["name"])
            u = '%s?action=play&name=%s&url=%s&content_type=%s&imdb=%s&year=%s' % (sys.argv[0], sysname, params["url"], params["content_type"], params["imdb"], params["year"])

            meta = {'title': xbmc.getInfoLabel('ListItemNoWrap(%s).title' % i), 'tvshowtitle': xbmc.getInfoLabel('ListItemNoWrap(%s).tvshowtitle' % i), 'season': xbmc.getInfoLabel('ListItemNoWrap(%s).season' % i), 'episode': xbmc.getInfoLabel('ListItemNoWrap(%s).episode' % i), 'writer': xbmc.getInfoLabel('ListItemNoWrap(%s).writer' % i), 'director': xbmc.getInfoLabel('ListItemNoWrap(%s).director' % i), 'rating': xbmc.getInfoLabel('ListItemNoWrap(%s).rating' % i), 'duration': xbmc.getInfoLabel('ListItemNoWrap(%s).duration' % i), 'premiered': xbmc.getInfoLabel('ListItemNoWrap(%s).premiered' % i), 'plot': xbmc.getInfoLabel('ListItemNoWrap(%s).plot' % i)}
            poster, fanart = xbmc.getInfoLabel('ListItemNoWrap(%s).icon' % i), xbmc.getInfoLabel('ListItemNoWrap(%s).Property(Fanart_Image)' % i)

            item = xbmcgui.ListItem(label, iconImage="DefaultVideo.png", thumbnailImage=poster)
            item.setInfo( type="Video", infoLabels= meta )
            item.setProperty("IsPlayable", "true")
            item.setProperty("Video", "true")
            item.setProperty("Fanart_Image", fanart)
            playlist.add(u, item)
        xbmc.Player().play(playlist)

    def playlist_open(self):
        xbmc.executebuiltin('ActivateWindow(VideoPlaylist)')

    def settings_open(self):
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % (addonId))

    def addon_home(self):
        xbmc.executebuiltin('Container.Update(plugin://%s/,replace)' % (addonId))

    def view(self, content):
        try:
            skin = xbmc.getSkinDir()
            skinPath = xbmc.translatePath('special://skin/')
            xml = os.path.join(skinPath,'addon.xml')
            file = xbmcvfs.File(xml)
            read = file.read().replace('\n','')
            file.close()
            try: src = re.compile('defaultresolution="(.+?)"').findall(read)[0]
            except: src = re.compile('<res.+?folder="(.+?)"').findall(read)[0]
            src = os.path.join(skinPath, src)
            src = os.path.join(src, 'MyVideoNav.xml')
            file = xbmcvfs.File(src)
            read = file.read().replace('\n','')
            file.close()
            views = re.compile('<views>(.+?)</views>').findall(read)[0]
            views = [int(x) for x in views.split(',')]
            for view in views:
                label = xbmc.getInfoLabel('Control.GetLabel(%s)' % (view))
                if not (label == '' or label is None): break
            file = xbmcvfs.File(viewData)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write = [i for i in write if not '"%s"|"%s"|"' % (skin, content) in i]
            write.append('"%s"|"%s"|"%s"' % (skin, content, str(view)))
            write = '\r\n'.join(write)
            file = xbmcvfs.File(viewData, 'w')
            file.write(str(write))
            file.close()
            viewName = xbmc.getInfoLabel('Container.Viewmode')
            self.index().infoDialog('%s%s%s' % (xbmcaddon.Addon().getLocalizedString(30301).encode("utf-8"), viewName, xbmcaddon.Addon().getLocalizedString(30302).encode("utf-8")))
        except:
            return

    def favourite_add(self, data, id, name, url, image, imdb, year):
        try:
            self.index().container_refresh()
            file = xbmcvfs.File(data)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write.append('"%s"|"%s"|"%s"|"%s"|"%s"|"%s"' % (id, name, year, imdb, url, image))
            write = '\r\n'.join(write)
            file = xbmcvfs.File(data, 'w')
            file.write(str(write))
            file.close()
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30303).encode("utf-8"), name)
        except:
            return

    def favourite_from_search(self, data, id, name, url, image, imdb, year):
        try:
            file = xbmcvfs.File(data)
            read = file.read()
            file.close()
            if '"%s"' % url in read:
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30307).encode("utf-8"), name)
                return
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write.append('"%s"|"%s"|"%s"|"%s"|"%s"|"%s"' % (id, name, year, imdb, url, image))
            write = '\r\n'.join(write)
            file = xbmcvfs.File(data, 'w')
            file.write(str(write))
            file.close()
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30303).encode("utf-8"), name)
        except:
            return

    def favourite_delete(self, data, name, url):
        try:
            self.index().container_refresh()
            file = xbmcvfs.File(data)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write = [i for i in write if not '"%s"' % url in i]
            write = '\r\n'.join(write)
            file = xbmcvfs.File(data, 'w')
            file.write(str(write))
            file.close()
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30304).encode("utf-8"), name)
        except:
            return

    def favourite_moveUp(self, data, name, url):
        try:
            self.index().container_refresh()
            file = xbmcvfs.File(data)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            i = write.self.index([i for i in write if '"%s"' % url in i][0])
            if i == 0 : return
            write[i], write[i-1] = write[i-1], write[i]
            write = '\r\n'.join(write)
            file = xbmcvfs.File(data, 'w')
            file.write(str(write))
            file.close()
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30305).encode("utf-8"), name)
        except:
            return

    def favourite_moveDown(self, data, name, url):
        try:
            self.index().container_refresh()
            file = xbmcvfs.File(data)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            i = write.self.index([i for i in write if '"%s"' % url in i][0])
            if i+1 == len(write): return
            write[i], write[i+1] = write[i+1], write[i]
            write = '\r\n'.join(write)
            file = xbmcvfs.File(data, 'w')
            file.write(str(write))
            file.close()
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30306).encode("utf-8"), name)
        except:
            return

    def metadata(self, content, name, url, imdb, season, episode):
        try:
            list = []
            if content == 'movie' or content == 'tvshow':
                if content == 'movie':
                    search = metaget.search_movies(name)
                elif content == 'tvshow':
                    search = []
                    result = metahandlers.TheTVDB().get_matching_shows(name)
                    for i in result: search.append({'tvdb_id': i[0], 'title': i[1], 'imdb_id': i[2]})
                for i in search:
                    label = i['title']
                    if 'year' in i: label += ' (%s)' % i['year']
                    list.append(label)
                select = self.index().selectDialog(list, xbmcaddon.Addon().getLocalizedString(30364).encode("utf-8"))
                if select > -1:
                    if content == 'movie':
                        new_imdb = metaget.get_meta('movie', search[select]['title'] ,year=search[select]['year'])['imdb_id']
                    elif content == 'tvshow':
                        new_imdb = search[select]['imdb_id']
                    new_imdb = re.sub('[^0-9]', '', new_imdb)
                    sources = []
                    try: sources.append(favData)
                    except: pass
                    try: sources.append(favData2)
                    except: pass
                    try: sources.append(subData)
                    except: pass
                    if sources == []: raise Exception()
                    for source in sources:
                        try:
                            file = xbmcvfs.File(source)
                            read = file.read()
                            file.close()
                            line = [x for x in re.compile('(".+?)\n').findall(read) if '"%s"' % url in x][0]
                            line2 = line.replace('"0"', '"%s"' % new_imdb).replace('"%s"' % imdb, '"%s"' % new_imdb)
                            write = read.replace(line, line2)
                            file = xbmcvfs.File(source, 'w')
                            file.write(str(write))
                            file.close()
                        except:
                            pass
                    metaget.update_meta(content, '', imdb, year='')
                    self.index().container_refresh()
            elif content == 'season':
                metaget.update_episode_meta('', imdb, season, episode)
                self.index().container_refresh()
            elif content == 'episode':
                metaget.update_season('', imdb, season)
                self.index().container_refresh()
        except:
            return

    def metadata2(self, content, imdb, season, episode):
        try:
            if content == 'movie' or content == 'tvshow':
                metaget.update_meta(content, '', imdb, year='')
                self.index().container_refresh()
            elif content == 'season':
                metaget.update_episode_meta('', imdb, season, episode)
                self.index().container_refresh()
            elif content == 'episode':
                metaget.update_season('', imdb, season)
                self.index().container_refresh()
        except:
            return

    def playcount(self, content, imdb, season, episode):
        try:
            metaget.change_watched(content, '', imdb, season=season, episode=episode, year='', watched='')
            self.index().container_refresh()
        except:
            return

    def library_add(self, subData, id, name, url, image, imdb, year, update=True, silent=False):
        try:
            file = xbmcvfs.File(subData)
            read = file.read()
            file.close()

            self.library(id, name, url, imdb, year, silent=True)

            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write.append('"%s"|"%s"|"%s"|"%s"|"%s"|"%s"' % (id, name, year, imdb, url, image))
            write = '\r\n'.join(write)
            file = xbmcvfs.File(subData, 'w')
            file.write(str(write))
            file.close()
            if silent == False:
                self.index().container_refresh()
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30312).encode("utf-8"), name)
            if update == True:
                xbmc.executebuiltin('UpdateLibrary(video)')
        except:
            return

    def library_from_search(self, subData, id, name, url, image, imdb, year, update=True, silent=False):
        try:
            file = xbmcvfs.File(subData)
            read = file.read()
            file.close()

            if '"%s"' % url in read:
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30316).encode("utf-8"), name)
                return

            self.library(id, name, url, imdb, year, silent=True)

            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write.append('"%s"|"%s"|"%s"|"%s"|"%s"|"%s"' % (id, name, year, imdb, url, image))
            write = '\r\n'.join(write)
            file = xbmcvfs.File(subData, 'w')
            file.write(str(write))
            file.close()
            if silent == False:
                self.index().container_refresh()
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30312).encode("utf-8"), name)
            if update == True:
                xbmc.executebuiltin('UpdateLibrary(video)')
        except:
            return

    def library_delete(self, subData, name, url, silent=False):
        try:
            file = xbmcvfs.File(subData)
            read = file.read()
            file.close()
            write = [i.strip('\n').strip('\r') for i in read.splitlines(True) if i.strip('\r\n')]
            write = [i for i in write if not '"%s"' % url in i]
            write = '\r\n'.join(write)
            file = xbmcvfs.File(subData, 'w')
            file.write(str(write))
            file.close()

            if silent == False:
                self.index().container_refresh()
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30313).encode("utf-8"), name)
        except:
            return

    def library_update(self, subData, silent=False):
        try:
            file = xbmcvfs.File(subData)
            read = file.read()
            file.close()
            match = re.compile('"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"[|]"(.+?)"').findall(read)
            for name, year, imdb, url, image in match:
                if xbmc.abortRequested == True: sys.exit()
                self.library(name, url, imdb, year, silent=True)
            if xbmcaddon.Addon().getSetting("updatelibrary") == 'true':
                xbmc.executebuiltin('UpdateLibrary(video)')
            if silent == False:
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30314).encode("utf-8"))
        except:
            return

    def library(self, id, name, url, imdb, year, check=False, silent=False):
        try:
            library = xbmc.translatePath(xbmcaddon.Addon().getSetting("tv_library"))
            xbmcvfs.mkdir(dataPath)
            xbmcvfs.mkdir(library)
            show = name
            seasonList = self.index().get_seasons(id)
        except:
            return

        try:
            for i in seasonList:
                season, seasonUrl, show_alt = i['name'], i['url'], i['title']
                enc_show = show_alt.translate(None, '\/:*?"<>|')
                folder = os.path.join(library, enc_show)
                xbmcvfs.mkdir(folder)
                enc_season = season.translate(None, '\/:*?"<>|')
                seasonDir = os.path.join(folder, enc_season)
                xbmcvfs.mkdir(seasonDir)

                episodeList = self.index().get_episodes(id, season) #episodes().get(season, seasonUrl, '', year, imdb, '', '', show_alt, idx_data, idx=False)
                for i in episodeList:
                    name, url, imdb = i['name'], i['url'], i['imdb']
                    sysname, sysurl, sysimdb, sysyear = urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(imdb), urllib.quote_plus(year)
                    content = '%s?action=play&name=%s&url=%s&content_type=shows&imdb=%s&year=%s' % (sys.argv[0], sysname, sysurl, sysimdb, sysyear)
                    enc_name = name.translate(None, '\/:*?"<>|')
                    stream = os.path.join(seasonDir, enc_name + '.strm')
                    file = xbmcvfs.File(stream, 'w')
                    file.write(str(content))
                    file.close()
            if silent == False:
                self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30311).encode("utf-8"), show)
        except:
            return

    def download(self, name, url):
        try:
            property = (xbmcaddon.Addon().getAddonInfo("name")+name)+'download'
            download = xbmc.translatePath(xbmcaddon.Addon().getSetting("downloads"))
            dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (xbmcaddon.Addon().getAddonInfo("id")))
            enc_name = name.translate(None, '\/:*?"<>|')
            xbmcvfs.mkdir(dataPath)
            xbmcvfs.mkdir(download)

            file = [i for i in xbmcvfs.listdir(download)[1] if i.startswith(enc_name + '.')]
            if not file == []: file = os.path.join(download, file[0])
            else: file = None
            if download == '':
            	yes = self.index().yesnoDialog(xbmcaddon.Addon().getLocalizedString(30341).encode("utf-8"), xbmcaddon.Addon().getLocalizedString(30342).encode("utf-8"))
            	if yes: self.settings_open()
            	return

            if file is None:
            	pass
            elif not file.endswith('.tmp'):
            	yes = self.index().yesnoDialog(xbmcaddon.Addon().getLocalizedString(30343).encode("utf-8"), xbmcaddon.Addon().getLocalizedString(30344).encode("utf-8"), name)
            	if yes:
            	    xbmcvfs.delete(file)
            	else:
            	    return
            elif file.endswith('.tmp'):
            	if self.index().getProperty(property) == 'open':
            	    yes = self.index().yesnoDialog(xbmcaddon.Addon().getLocalizedString(30345).encode("utf-8"), xbmcaddon.Addon().getLocalizedString(30346).encode("utf-8"), name)
            	    if yes: self.index().setProperty(property, 'cancel')
            	    return
            	else:
            	    xbmcvfs.delete(file)

            if url is None: return
            stream = os.path.join(download, enc_name + '.mp4')
            temp = stream + '.tmp'

            count = 0
            CHUNK = 16 * 1024
            request = urllib2.Request(url)
            request.add_header('User-Agent', 'Kodi (%s)' % xbmcaddon.Addon().getAddonInfo("version"))
            request.add_header('Cookie', 'video=true')
            request.add_header("Authorization", "Basic %s" % base64.b64encode('%s:%s' % (xbmcaddon.Addon().getSetting('user'), xbmcaddon.Addon().getSetting('password'))))
            response = urllib2.urlopen(request)
            size = response.info()["Content-Length"]

            file = xbmcvfs.File(temp, 'w')
            self.index().setProperty(property, 'open')
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30308).encode("utf-8"), name)
            while True:
            	chunk = response.read(CHUNK)
            	if not chunk: break
            	if self.index().getProperty(property) == 'cancel': raise Exception()
            	if xbmc.abortRequested == True: raise Exception()
            	part = xbmcvfs.File(temp)
            	quota = int(100 * float(part.size())/float(size))
            	part.close()
            	if not count == quota and count in [0,10,20,30,40,50,60,70,80,90]:
            		self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30309).encode("utf-8") + str(count) + '%', name)
            	file.write(chunk)
            	count = quota
            response.close()
            file.close()

            self.index().clearProperty(property)
            xbmcvfs.rename(temp, stream)
            self.index().infoDialog(xbmcaddon.Addon().getLocalizedString(30310).encode("utf-8"), name)
        except:
            file.close()
            self.index().clearProperty(property)
            xbmcvfs.delete(temp)
            sys.exit()
            return
